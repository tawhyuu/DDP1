list_kucing_itb = 'Puss-2-British Shorthair-Orange,Scar-5-Sphynx-White,Jelly-1-American Wirehair-Grey,Yawhi-3-Siamese-White,Mi-3-Munchkin-Orange,Anak-2-Angora-Black,Rav-6-Angora-Brown'
list_kucing_itb = list_kucing_itb.lower()
list_kucing_itb_split = list_kucing_itb.split(',')

list_kucing_ui = 'Leon-2-Somali-Grey','Sa-2-American Curl-White','Panda-4-Exotic Shorthair-Black','Lala-3-LaPerm-Black','Ninya-2-Somali-Beige','Vae1-LaPerm-Grey','Rinny-4-Highlander-Grey'

kucing_itb = 'Puss-2-British Shorthair-Orange-Scar-5-Sphynx-White-Jelly-1-American Wirehair-Grey-Yawhi-3-Siamese-White-Mi-3-Munchkin-Ora​nge-Anak-2-Angora-Black-Rav-6-Angora-Brown'
kucing_itb_split = kucing_itb.split("-")

kucing_ui = 'Leon-2-Somali-Grey-Sa-2-American Curl-White-Panda-4-Exotic Shorthair-Black-Lala-3-LaPerm-Black-Ninya-2-Somali-Beige-Vae-1-LaPerm-Grey-Rinny-4-Highlander-Grey'
kucing_ui_split = kucing_ui.split("-")

print("""Selamat datang di DepeCat!
Berikut list universitas yang menyediakan adopsi kucing:
1) UI
2) ITB """)

action = input('Masukkan pilihan sesuai angka yang tertera di depan nama universitas: ')
if action == "1":
    data_kucing = list_kucing_ui
else:
    data_kucing = list_kucing_itb
print()
print("""Silahkan pilih menu
1) Cetak semua data kucing
2) Cari kucing""")

pilihan = input("Pilihan: ")
if pilihan == "1":
    print("{:<10} | {:<6} | {:<20} | {:<10}".format("Nama", "Umur", "Jenis", "Warna"))
    print("{:<10} | {:<6} | {:<20} | {:<10}".format("-"*10, "-"*6, "-"*20, "----------"))
    if action == "1":
        for i in range(7):
            print("{:<10} | {:<6} | {:<20} | {:<10}".format(kucing_ui_split[i*4], kucing_ui_split[i*4+1], kucing_ui_split[i*4+2], kucing_ui_split[i*4+3]))
    else:
        for j in range(7):
            print("{:<10} | {:<6} | {:<20} | {:<10}".format(kucing_itb_split[j*4], kucing_itb_split[j*4+1], kucing_itb_split[j*4+2], kucing_itb_split[j*4+3]))
    print("\nTerima kasih telah mengunjungi DepeCat!")

# Maaf kak ini sudah expert banget saya tidak mengerti
elif pilihan == "2":
    key_word = input("\nMasukkan kata kunci pencarian: ")
    lower_keyword = key_word.lower()
    if action == "1":
        kucing_ui = kucing_ui.lower()
        x = kucing_ui.find(lower_keyword)
        print(x)

    else:
        kucing_itb = kucing_itb
        y = kucing_itb.find(lower_keyword)
        print(y)

# Maaf kak kalau pusing baca kodenya
        

